<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Validator\Digits;
use Zend\I18n\Validator\Alpha;
use Zend\Validator\EmailAddress;

class GalleryController extends AbstractActionController
{
    public function indexAction()
    {
        $alphaValidator = new Alpha();
        $name = $this->getRequest()->getQuery('name');
/*        var_dump($name, 'this is it');
        if (isset($name)) {
            echo "it is set";
        }
        if ($name == NULL) {
            echo "it is NULL";
        }*/
        if ($name !== NULL) {
            if ($alphaValidator->isValid($name)) {
                echo 'You entered the name: ' . $name;
            } else {
                echo 'You entered an invalid name.   It must only contain letters!: ' . $name;
            }
        }

        return new ViewModel();
    }
}

